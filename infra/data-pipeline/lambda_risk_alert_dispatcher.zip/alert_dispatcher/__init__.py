"""Risk alert dispatcher package."""
